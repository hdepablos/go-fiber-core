# Specs para IA y Spec-Driven Development

`doc/specs/` contiene documentos normativos para asistentes, automatizaciones y flujos de Spec-Driven Development.
Estas specs no reemplazan la documentacion humana: la complementan.

## Principios

- `doc/info/` explica el contexto para personas.
- `doc/specs/` define contratos, invariantes y criterios de aceptacion.
- Cada spec debe apuntar a codigo, pruebas o documentos humanos relacionados.
- Ninguna spec debe duplicar una guia operativa completa; debe formalizar reglas verificables.

## Metadata recomendada

Las specs nuevas y las specs que se migren deben incluir metadata breve al inicio del archivo para mejorar:

- la navegacion por dominio,
- la trazabilidad con codigo y guias humanas,
- la decision de que spec revisar segun el tipo de cambio,
- y futuras automatizaciones de indices en `AGENTS.md` y este `README`.

Campos minimos esperados:

- `domain`
- `summary`
- `when_to_read`
- `code_paths`
- `related_info`

Campos recomendados:

- `related_specs`
- `status`

Ejemplo:

```md
---
domain: api
summary: Contrato documental minimo para endpoints HTTP, handlers, DTOs y requests Bruno.
when_to_read:
  - cambios en endpoints HTTP
  - cambios en DTOs
code_paths:
  - internal/routes/
  - internal/handlers/
  - bruno/api/
related_info:
  - doc/info/api/http-endpoints-guide.md
related_specs:
  - doc/specs/documentation-governance-spec.md
status: active
---
```

## Specs Disponibles

### Gobierno documental

- [documentation-governance-spec.md](documentation-governance-spec.md)
- [documentation-defaults-spec.md](documentation-defaults-spec.md)

### Shared

- [shared-utils-spec.md](shared/shared-utils-spec.md)

### Architecture

- [core-architecture-spec.md](architecture/core-architecture-spec.md)
- [external-http-client-spec.md](architecture/external-http-client-spec.md)
- [service-design-spec.md](architecture/service-design-spec.md)
- [service-runtime-bootstrap-spec.md](architecture/service-runtime-bootstrap-spec.md)

### API

- [http-endpoints-spec.md](api/http-endpoints-spec.md)

### Platform

- [platform-runtime-spec.md](platform/platform-runtime-spec.md)
- [logger-runtime-spec.md](platform/logger-runtime-spec.md)
- [makefile-automation-spec.md](platform/makefile-automation-spec.md)
- [process-scaffold-cleanup-spec.md](platform/process-scaffold-cleanup-spec.md)

### Process Lifecycle

- [batch-fanout-spec.md](process-lifecycle/batch-fanout-spec.md)
- [batch-observability-spec.md](process-lifecycle/batch-observability-spec.md)
- [batch-preview-spec.md](process-lifecycle/batch-preview-spec.md)
- [process-lifecycle-runtime-spec.md](process-lifecycle/process-lifecycle-runtime-spec.md)

### Exports

- [export-pipelines-spec.md](exports/export-pipelines-spec.md)

### Data

- [database-schema-query-spec.md](data/database-schema-query-spec.md)

## Plantilla Recomendada

Toda nueva spec deberia incluir:

1. Objetivo
2. Alcance
3. Contratos de entrada y salida
4. Invariantes
5. Errores esperados
6. Acceptance criteria
7. Trazabilidad a `doc/info`, codigo y pruebas
