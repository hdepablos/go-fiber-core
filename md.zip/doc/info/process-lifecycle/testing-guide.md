# Guía de Pruebas de Process Lifecycle

A continuación se detallan los pasos para probar cada uno de los escenarios implementados.

**Nota Importante:** Los IDs mostrados a continuación asumen una base de datos limpia. Si has corrido el seeder múltiples veces, los IDs pueden variar.

## 1. Ejecutar Seeder

El seeder limpia y repobla las tablas necesarias (`process_types`, `process_versions`, `process_steps`).

**Usando Makefile (Recomendado):**
Este comando ejecuta el seeder dentro del contenedor Docker, asegurando que tenga acceso correcto a la red y base de datos.

```bash
make seed-one name=process_lifecycle_manager
```

**Opción Manual (Solo si tienes Go y BD local configurada):**
```bash
go run cmd/cmd-cli/main.go seed --only process_lifecycle_manager
```

---

## Caso 1: Ejecución Secuencial Simple (SYNC)

**Descripción:** 3 pasos simples (Validar -> Calcular -> Notificar) ejecutados en memoria.
**IDs Esperados:** `process_type_id: 2`, `process_version_id: 2` (DRAFT)

### Request
**Endpoint:** `POST /api/v1/process-lifecycle/run`

```json
{
  "process_type_id": 2,
  "sede_id": 1,
  "override_process_version_id": 2,
  "roadmap": 0,
  "input": {
    "age": 25,
    "email": "test@example.com"
  }
}
```

### Salida Esperada
```json
{
  "status": "success",
  "data": {
    "process_version_id": 2,
    "result": {
      "common/validate": { "status": "completed", "data": { "valid": true } },
      "common/calculate": { "status": "completed", "data": { "result": 37.5 } }, // 25 * 1.5
      "common/notify": { "status": "completed", "data": { "sent": true } }
    }
  }
}
```

**Explicación:** El motor ejecuta los 3 pasos uno tras otro y devuelve el resultado consolidado inmediatamente.

---

## Preview de Exports

Para exportaciones basadas en `exportmanager` existe un endpoint de preview que reutiliza la misma implementación del proceso real:

- endpoint: `POST /api/v1/process-lifecycle/export-preview`
- colección Bruno canónica: `bruno/api/v1/process-lifecycle/post-export-preview.bru`
- variantes históricas preservadas: `bruno/legacy/process-lifecycle/test-export`

Ejemplo:

```json
{
  "process_type_id": 17,
  "sede_id": 0,
  "override_process_version_id": 0,
  "roadmap": 0,
  "mode": "prepare",
  "input": {
    "id": 2,
    "key_redis": "preview-001",
    "filters": [
      {
        "field": "status_code",
        "operator": "eq",
        "value": "ERROR_PROCESS"
      }
    ]
  }
}
```

Reglas:

- `override_process_version_id = 0`: preview contra la versión resuelta en producción
- `override_process_version_id > 0`: preview contra una versión específica sin importar su estado
- `roadmap`: usa la misma lógica de resolución del lifecycle normal
- `mode`: `prepare`, `header`, `body`, `footer`, `all`

## Preview de Batchflow

Para procesos batch basados en `batchflow` existe el endpoint:

- endpoint: `POST /api/v1/process-lifecycle/batch-preview`
- requests históricos base: `bruno/legacy/process-lifecycle/test-batch-process/`

Casos cubiertos:

- `prepare`: prepara la sesión y guarda lotes temporales en Redis
- `all`: inspecciona una ventana del universo preparado
- `batch`: inspecciona por `batch_index`, `item_ids` o `row_numbers`
- `apply_changes=true`: inspecciona y además ejecuta la persistencia real de la selección, solo en local
- `run` filtrado: ejecuta el lifecycle real usando filtros del `DataProvider`

Documento detallado:

- `doc/info/process-lifecycle/batch-preview-guide.md`
- `doc/info/process-lifecycle/dispatch-pacing-guide.md`

## Dispatch Pacing en `process_batch`

Los procesos batch pueden dosificar el procesamiento por tandas usando `dispatch_pacing` dentro del config del step `process_batch`.

Ejemplo:

```json
{
  "dispatch_pacing": {
    "enabled": true,
    "messages_per_interval": 3,
    "interval_seconds": 5
  }
}
```

Esto permite probar escenarios como:

- procesar `3` items,
- re-encolar la siguiente tanda `5` segundos después,
- continuar con los siguientes `3`.

### Qué probar en local

1. Configurar el step `process_batch` con `dispatch_pacing`.
2. Ejecutar `preview apply_changes` con `10` registros.
3. Confirmar que la respuesta contiene `apply_changes_metadata.dispatch_pacing`.
4. Verificar:
   - `chunk_count`
   - `chunk_sizes`
   - `waits_ms`
   - `mode`
   - `simulated`

Requests recomendados:

- `bruno/api/v1/process-lifecycle/post-batch-preview-apply-changes-pacing.bru`
- `bruno/legacy/process-lifecycle/test-batch-process/preview - batch - item_ids - apply_changes.bru`

### Qué diferencia hay entre `preview` y `run`

- `preview apply_changes`:
  - sirve para validar el pacing con una muestra controlada,
  - devuelve metadata detallada del pacing,
  - simula el delay sin dormir el request HTTP,
  - no ejecuta el lifecycle completo del padre.
- `run`:
  - ejecuta el lifecycle completo,
  - respeta el mismo `dispatch_pacing` del step,
  - usa `auto_invoke` con delay entre invocaciones,
  - pero ya no está acotado a la muestra del preview.

## Fan-out Batch para Lambda/EKS

Los procesos batch ya contemplan un modo de fan-out distribuido basado en:

- `start`
- `dispatch_shards`
- `process_batch`
- `finalize`

Documentos relacionados:

- `doc/info/process-lifecycle/batch-fanout-guide.md`
- `doc/info/process-lifecycle/batch-fanout-risks.md`
- `doc/specs/process-lifecycle/batch-fanout-spec.md`

## Caso 2: Ejecución Paralela y Recursiva (ASYNC Batching)

**Descripción:** 4 Workers Async (Paralelos) + 1 Consolidación Final.
**IDs Esperados:** `process_type_id: 3`, `process_version_id: 3` (DRAFT)

### Request
**Endpoint:** `POST /api/v1/process-lifecycle/run`

```json
{
  "process_type_id": 3,
  "sede_id": 1,
  "override_process_version_id": 3,
  "roadmap": 0,
  "input": {
    "partition_id": "A1",
    "last_id_processed": 0
  }
}
```

### Salida Esperada
```json
{
  "status": "success",
  "data": {
    "process_version_id": 3,
    "result": {
      "batch/processor": { 
        "status": "pending", 
        "message": "Step dispatched to queue: batch-queue" 
      }
    }
  }
}
```

**Explicación:**
1. La API responde rápido indicando que el proceso "batch/processor" fue enviado a la cola (ASYNC).
2. En background (SQS), 4 workers procesarán lotes.
3. Cada worker se re-invocará (`auto_invoke`) hasta terminar su partición.
4. Cuando terminen, se disparará el paso "batch/consolidate".

---

## Caso 3: Flujo Híbrido (Sync -> Async -> Sync)

**Descripción:** Validación Sync -> Proceso Pesado Async -> Notificación.
**IDs Esperados:** `process_type_id: 4`, `process_version_id: 4` (DRAFT)

### Request
**Endpoint:** `POST /api/v1/process-lifecycle/run`

```json
{
  "process_type_id": 4,
  "sede_id": 1,
  "override_process_version_id": 4,
  "roadmap": 0,
  "input": {
    "file_url": "http://s3...",
    "user_id": 99
  }
}
```

### Salida Esperada
```json
{
  "status": "success",
  "data": {
    "process_version_id": 4,
    "result": {
      "common/validate": { 
        "status": "completed", 
        "data": { "file_valid": true } 
      },
      "heavy/process": { 
        "status": "pending", 
        "message": "Step dispatched to queue: vip-queue" 
      }
    }
  }
}
```

**Explicación:**
1. El paso "common/validate" se ejecuta y pasa (SYNC).
2. El paso "heavy/process" se detecta como ASYNC y se manda a la cola `vip-queue`.
3. La API detiene la ejecución aquí y responde al cliente.
4. El paso "common/notify" NO se ejecuta todavía; esperará a que el worker termine el paso pesado.
